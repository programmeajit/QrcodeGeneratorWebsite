from django.shortcuts import render,HttpResponseRedirect
from . forms import SignUPForm,LoginForm
from django.contrib.auth import authenticate,login, logout
from django.contrib import messages
import qrcode
from datetime import date
# Create your views here.
# Home
def home(request):
    return render(request, 'enroll/home.html')
# signup
def user_signup(request):
    if request.method == "POST":
        fm = SignUPForm(request.POST)
        if fm.is_valid():
            user = fm.save()
    else:
        fm = SignUPForm()
    return render(request, 'enroll/signup.html' ,{"form" : fm})


# Logout
def user_logout(request):
    if request.user.is_authenticated:
        logout(request)
        return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')


# Login
def user_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fm = LoginForm(request=request, data =request.POST)
            if fm.is_valid():
                uname  = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request,user)
                    return HttpResponseRedirect('/')
        else:
            fm = LoginForm()
        return render(request, 'enroll/login.html',{"form":fm})
    else:
        return HttpResponseRedirect('/')

def qrcodegen(request):

    if(request.method == "POST"):
        data = request.POST
        # qrcode generation coding 
        information = {"Name" : data["name"],
                        "Email" : data["email"],
                        "Phone" : data["phone"],
                        "Address":data['address'],
                        }
        
        info=qrcode.make(information)
        path = data["email"] + ".png"
        info.save(path)
        
        return render(request,"enroll\qrcode.html")

    else:
        return render(request,"enroll\qrcode.html")
